FINITE DIFFERENCE METHODS
=========================

A finite difference is a technique by which derivatives of functions are approximated by
differences in the values of the function between a given value of the independent
variable, say $x_0$

There are 3 types of finite difference methods used for such approximations:

   + FORWARD DIFFERENCE
 
  The approximation
$$\frac{df}{dx}=\frac{f(x_0+h)-f(x_0)}{h}$$
is called a forward difference formula because the derivative is based on the value x=$x_0$
and it involves the function f(x) evaluated at $x = x_0+h$, i.e., at a point located forward from $x_0$ by an increment h. 



   + BACKWARD DIFFERENCE
   
   If we include the values of f(x) at x = $x_0$ - h, and x = $x_0$, the approximation is written as
   
$$\frac{df}{dx}=\frac{f(x_0)-f(x_0-h)}{h}$$

    and is called a backward difference formula. In both the cases the order of error is h.
    
   + CENTRAL DIFFERNCE
   
   using the central difference method the derivative can be approximated as 
   
   $$\frac{df}{dx}=\frac{f(x_0+h)-f(x_0-h)}{2h}$$
   
   the order of error in this case is $h^2$ thus it provides a better approximation given that our function is smooth and we dont have any issues along the boundaries.
   
   To obtain more accurate approximations we can use higher order derivatives but at the cost of making
the differences more expensive to compute. Other limitations of this method are faced with practical PDE problems which contain discontinuities (e.g. Heat flow through two mediums), in such cases the Taylor-series approximation is no longer valid.



```julia
f(x) = x^4

h = 10^(-100)
x = 1

df = (f(x+h) - f(x))/h

```




    0.000000000000000




```julia
## A comparison between forward,central and backward difference scheme
using PyPlot

x0=1;

f(x) = x*x*x - x*x + 2.0x + 2.0;
#f(x)=x*x*x;
#f(x)=sin(x);
#f(x)=sin(x)+cos(x);



dx=zeros(18,1)
for i = 1:18;
    dx[i]=10.0^-i
end

err1=zeros(18,1)
err2=zeros(18,1)
err3=zeros(18,1)
for j=1:18;
    
    err1[j]=abs((f(x0+dx[j])-f(x0))/dx[j] - 3.0*x0*x0+2.0x0*x0-2.0)
    # doesnt work good for x=2,3,4
    err2[j]=abs((f(x0+dx[j])-f(x0-dx[j]))/2/dx[j] - 3.0*x0*x0+2.0x0*x0-2.0)
    err3[j]=abs((f(x0)-f(x0-dx[j]))/dx[j] - 3.0*x0*x0+2.0x0*x0-2.0)
    #err[j]=abs((f(x0+dx[j])-f(x0-dx[j]))/2/dx[j] - 3.0*x0*x0) # good for all x0 best 1,2
    #err[j]=abs((f(x0+dx[j])-f(x0-dx[j]))/2/dx[j] - cos(x0)) #fails at x=0
    #err[j]=abs((f(x0+dx[j])-f(x0-dx[j]))/2/dx[j] - cos(x0)+sin(x0))

end


loglog(dx,err1,"-*",linewidth=2,label="Forward difference")
loglog(dx,err2,"-o",linewidth=2,label="Central difference")
loglog(dx,err3,"-s",linewidth=1,label="Backward difference")
xlabel("Step Size")
ylabel("Error ")
title("Error Vs Step Size for finite difference methods")
grid("on")
legend(loc="upper right",fancybox="true")



```


    
![png](output_2_0.png)
    





    PyObject <matplotlib.legend.Legend object at 0x7fb2feea2cc0>



SENSITIVITY TO STEP SIZE
-----------------------

Inappropriate step size could affect the optimization stability and efficiency.

The main sources of errors in finite difference methods are truncation errors. It's the error made by truncating an infinite sum (e.g. Taylor series) and approximating it by a finite sum.
As we can see from the plot, the truncation error decreases and reaches a minimun. 
As we go on decreasing the step size the subtractive cancellation error due to finite precision arithmetic gets added. Thus the error goes on increasing.

The optimal step size can be determined from sensitivity analysis to minimize the total numerical error, yet this will introduce additional computational burdens. 

COMPLEX VARIABLE TRICK
----------------------

 Given a function that is infinitely differentiable and can be smoothly extended into the complex plane. We can write it as F(z) and such function can be expanded about $x_0$ using the Taylor series.
 
 $$F(x_0+ih)=F(x_0)+ihF'(x_0)−\frac{h^2F″(x_0)}{2!}−i\frac{h^3F^{(3)}}{3!}+....$$
 
 Take the imaginary part of both sides and divide by h.
 
 $$F′(x_0)=Im(\frac{F(x_0+ih)}{h})+O(h^2)$$
 
 Evaluating the function $F$ for an imaginary argument $x_0+ih$ and dividing by h, gives an approximation to the value of the derivative, $F′(x_0)$, that is accurate to order $O(h^2)$.

 



```julia
using PyPlot
using LinearAlgebra
using Printf

N = 15
x0 = 1.0
f(x)=x*x*x
∇f(x) = 3*x*x

∇f_cd(x,Δx) = (f(x+Δx) - f(x-Δx))/2Δx 
∇f_cs(x,Δx) = imag(f(x0 + im*Δx)/Δx)

err1=zeros(N,1); err2 = zeros(N,1)
Δx = 10.0.^collect(-1:-1:-N)
for j=1:N
    err1[j]=norm(∇f_cs(x0,Δx[j]) - ∇f(x0)) 
    err2[j]=norm(∇f_cd(x0,Δx[j]) - ∇f(x0))
end

loglog(Δx,err1,label="Complex Step Differentiation")
loglog(Δx,err2,label="Central difference")
xlabel("Step Size"); ylabel("Error ")
title("Error Vs Step Size for complex variable trick and central difference methods")
grid("on"); legend(loc="upper right",fancybox="true")

```


    
![png](output_5_0.png)
    





    PyObject <matplotlib.legend.Legend object at 0x7f15d509e780>



## Automatic Differntiation (AD)

AD is the most promising method for calculating gradients and Hessians. AD goes through the source code of a function and differtiates the code line-by-line analytically. This involves carrying forward the perturbations in the functions from earlier. AD is available for almost all languages with varying degrees of sophestication. It is easier to create a AD software for low level languages like Fortran and C. Packages like Tapenade have matured to a degree that a successful application of AD technology has been made to industrial CFD softwares.
AD methods for higher level languages are not very robust. `Julia` has many experimental AD packages that use

- Source transformation
- operator overloading
- Dual numbers
- Hyper-dual numbers

to calculate $n^{th}$ order derivatives for native `Julia` functions.

AD can be applied in two modes:

- Forward mode (Tangent mode)
- Reverse mode (Adjoint mode)

Here we will demonstrate the AD capabilities of `Tapenade` to give a flavour of the process.

**Simple Fortran Example Using Tapenade**

`simpleTest.f`

~~~.f
      subroutine function(in1, in2, out)
          real*8 in1, in2, out
          real*8 tmp1, tmp2
          
          tmp1 = sin(in1)
          out = tmp1 + in2

          return
      end
~~~

**Commands to differentiate the code**

~~~.bash
tapenade -forward 
         -head function 
         -output function 
         -vars "in1, in2, out"
         -outvars "out"
         simpleTest.f
         
tapenade -reverse 
         -head function 
         -output function 
         -vars "in1, in2, out"
         -outvars "out"
         simpleTest.f
~~~

**Forward Differentiated code `simpleTest_d.f`**

~~~.f
C        Generated by TAPENADE     (INRIA, Tropics team)
C  Tapenade 3.9 (r5096) - 24 Feb 2014 16:53
C
C  Differentiation of function in forward (tangent) mode:
C   variations   of useful results: out
C   with respect to varying inputs: in1 in2
C   RW status of diff variables: out:out in1:in in2:in
      SUBROUTINE FUNCTION_D(in1, in1d, in2, in2d, out, outd)
      IMPLICIT NONE
      REAL*8 in1, in2, out
      REAL*8 in1d, in2d, outd
      REAL*8 tmp1, tmp2
      REAL*8 tmp1d
      INTRINSIC SIN
      tmp1d = in1d*COS(in1)
      tmp1 = SIN(in1)
      outd = tmp1d + in2d
      out = tmp1 + in2
C
      RETURN
      END
~~~

**Reverse Differentiated code `simpleTest_b.f`**

~~~.f
C        Generated by TAPENADE     (INRIA, Tropics team)
C  Tapenade 3.9 (r5096) - 24 Feb 2014 16:53
C
C  Differentiation of function in reverse (adjoint) mode:
C   gradient     of useful results: out
C   with respect to varying inputs: out in1 in2
C   RW status of diff variables: out:in-zero in1:out in2:out
      SUBROUTINE FUNCTION_B(in1, in1b, in2, in2b, out, outb)
      IMPLICIT NONE
      REAL*8 in1, in2, out
      REAL*8 in1b, in2b, outb
      REAL*8 tmp1, tmp2
      REAL*8 tmp1b
      INTRINSIC SIN
C
      tmp1b = outb
      in2b = outb
      in1b = COS(in1)*tmp1b
      outb = 0.0
      END
~~~
